# JSN – clean-map website

## Files
- `index.html` – page structure (Map, Community cleans, Good news, Donate, Information tabs)
- `style.css` – colours and layout (theme colours are the CSS variables at the top)
- `app.js` – all the logic

## Run it
Open a terminal in this folder and run `python3 -m http.server 8000`, then visit http://localhost:8000.
To publish, upload the folder to Netlify, Vercel, Cloudflare Pages or GitHub Pages.
Once hosted this way you get real street-level map tiles (OpenStreetMap) and address search.

## Where to change things (search `app.js` for these)
- **Clean score formula:** `WEIGHTS`, `score`, `penalty` at the top.
- **Map grid size:** `CS` (0.05 degrees per area).
- **Demo data:** the block starting `// ---- demo data`. Delete it and the "Show demo data" checkbox in `index.html`.
- **Donation items and prices:** `GIVE` (each donation = x bin bags or litter pickers).
- **Kit bank (public stock):** `STOCK` in `app.js` (`in` = donated, `out` = lent out). Available = in minus out. Change the starting numbers there, or update them from an admin page once you have a backend. Update it only when donations are actually received.
- **Good news stories:** the `NEWS` list. The sample stories are placeholders, replace them with real ones.
- **Donate wording:** the `v4` section in `index.html`. Keep the not-a-charity line unless you become one, and say how donations are held and reported.
- **Learn tab:** the `v5` section (Information tab) in `index.html`.
- **Map lock area:** the bounds `-8.7, 2, 58.9, 49.8` in `render()`; minimum zoom in `zoomBy()`.

## What still depends on claude.ai (needs replacing)
The published version used claude.ai features that do not exist on your own host. Search `claude.use` in `app.js` (bottom of file). Until you replace them, the site runs in memory only: nothing is saved, and the AI does not run.

| Feature | Was | Replace with |
|---|---|---|
| Accounts | claude.ai identity (`user`) | Supabase Auth, Firebase Auth or Clerk |
| Saving reports, events, RSVPs | `db` | Supabase or Firebase (tables: reports, events) |
| Photo storage | `assets` | Supabase Storage, Firebase Storage or S3 |
| AI trash counting | `sample` | Call a vision model (e.g. the Claude API) from a **server function**. Never put an API key in `app.js`. Return `{items:[{type,count}]}` |
| Donate button | placeholder | Stripe payment link or a fundraising platform |

## Before launch (UK)
- Privacy policy and terms; register with the ICO (you store photos, locations, accounts).
- Donations: if you collect money from the public for a purpose (bin bags, litter pickers), spend it on that purpose and report it. Check with a solicitor whether you need a charity, CIC or a partner charity to hold the funds.
- OpenStreetMap tiles and Nominatim search have fair-use limits – move to a paid provider (MapTiler, Mapbox) for real traffic.
- Photo GPS: many phones strip location data when uploading; the manual pin is the fallback.
