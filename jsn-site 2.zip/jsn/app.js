// ===== Scoring model – edit these weights to tune the clean score =====
const WEIGHTS={plastic:3,glass:4,metal:3,paper:1,food:2,cigarettes:1,hazardous:10,flytipping:12,other:2};
const score=p=>Math.max(0,100-p);
const penalty=items=>(items||[]).reduce((s,i)=>s+(WEIGHTS[i.type]??2)*Math.min(+i.count||1,20),0);
// ======================================================================
const $=id=>document.getElementById(id),NS='http://www.w3.org/2000/svg',CS=.05;
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const GB=[[-5.7,50.05],[-5.2,49.96],[-4.2,50.35],[-3.4,50.6],[-2.45,50.55],[-1.4,50.75],[-.1,50.8],[1.4,51.15],[.7,51.5],[1.3,51.95],[1.75,52.6],[.3,52.9],[.3,53.1],[.1,53.6],[-.1,54.1],[-.6,54.5],[-1.4,55],[-2,55.75],[-3,56],[-2.6,56.3],[-2.05,57.1],[-1.8,57.5],[-3.5,57.7],[-4.2,57.5],[-3.9,57.85],[-3.05,58.65],[-5,58.6],[-5.2,57.9],[-5.7,57.3],[-5.8,56.7],[-5.6,56],[-5.7,55.3],[-4.6,55.45],[-5.1,54.85],[-3.6,54.9],[-3.2,54.1],[-3.05,53.85],[-3,53.4],[-4.3,53.3],[-4.7,52.8],[-4.1,52.4],[-5.2,51.9],[-4,51.6],[-3.2,51.45],[-2.7,51.5],[-4.5,51],[-5,50.55]];
const NI=[[-8,54.4],[-7,55.2],[-6.2,55.2],[-5.6,54.7],[-5.5,54.4],[-6,54],[-6.4,54.05],[-7.3,54.1]];
// ---- Web-Mercator slippy map ----
const wrap=$('mapwrap'),tl=$('tiles'),ov=$('ov'),T={};
let V={z:5,cx:0,cy:0},W=600,H=500,tilesOK=false,pinned=null,real=[],events=[],db=null,uid=null,useSample=null,assets=null,draft=[],photoBlob=null;
const S=z=>256*2**z,mx=(lo,z)=>(lo+180)/360*S(z);
const my=(la,z)=>{const r=la*Math.PI/180;return(1-Math.log(Math.tan(r)+1/Math.cos(r))/Math.PI)/2*S(z)};
const ilon=(x,z)=>x/S(z)*360-180,ila=(y,z)=>180/Math.PI*Math.atan(Math.sinh(Math.PI-2*Math.PI*y/S(z)));
const P=(lo,la)=>[mx(lo,V.z)-V.cx+W/2,my(la,V.z)-V.cy+H/2];
const poly=a=>a.map(([lo,la])=>P(lo,la).map(n=>n.toFixed(1)).join(',')).join(' ');
function setView(lo,la,z){V.z=z;V.cx=mx(lo,z);V.cy=my(la,z);render()}
const col=s=>`hsl(${s*1.3} 75% ${26+s*.24}%)`;
function cellsData(){const m={};reports.forEach(r=>{const k=Math.floor(r.lon/CS)+'_'+Math.floor(r.lat/CS);(m[k]=m[k]||{p:0,n:0,k}).p+=penalty(r.items);m[k].n++});return m}
function render(){
 W=wrap.clientWidth;H=wrap.clientHeight;const z=V.z,n=2**z,want={};
 {const a=mx(-8.7,z),b=mx(2,z),c=my(58.9,z),d=my(49.8,z);V.cx=b-a<W?(a+b)/2:Math.min(Math.max(V.cx,a+W/2),b-W/2);V.cy=d-c<H?(c+d)/2:Math.min(Math.max(V.cy,c+H/2),d-H/2)}
 $('attr').style.display=z>=9?'':'none';
 for(let x=Math.floor((V.cx-W/2)/256);x<=Math.floor((V.cx+W/2)/256);x++)for(let y=Math.floor((V.cy-H/2)/256);y<=Math.floor((V.cy+H/2)/256);y++){
  if(y<0||y>=n||z<9)continue;const tx=((x%n)+n)%n,k=z+'/'+tx+'/'+y+'@'+x;want[k]=1;let im=T[k];
  if(!im){im=T[k]=new Image();im.draggable=false;im.onload=()=>{tilesOK=true;render()};im.src=`https://tile.openstreetmap.org/${z}/${tx}/${y}.png`;tl.appendChild(im)}
  im.style.left=(x*256-V.cx+W/2)+'px';im.style.top=(y*256-V.cy+H/2)+'px'}
 for(const k in T)if(!want[k]){T[k].remove();delete T[k]}
 const cells=Object.values(cellsData()).map(c=>{const [i,j]=c.k.split('_').map(Number),[x1,y1]=P(i*CS,(j+1)*CS),[x2,y2]=P((i+1)*CS,j*CS),s=score(c.p);
  return `<rect data-k="${c.k}" x="${x1}" y="${y1}" width="${Math.max(x2-x1,5)}" height="${Math.max(y2-y1,5)}" fill="${col(s)}" fill-opacity=".72" stroke="${col(s)}"/>`}).join('');
 const pins=!showPins?'':reports.map(r=>{const [x,y]=P(r.lon,r.lat);return `<circle cx="${x}" cy="${y}" r="3" fill="#fff" stroke="#000" stroke-width=".7"/>`}).join('');
 let cur='';if(pinned){const [x,y]=P(pinned.lon,pinned.lat);cur=`<circle cx="${x}" cy="${y}" r="7" fill="#3a86ff" stroke="#fff" stroke-width="2"/>`}
 ov.setAttribute('viewBox',`0 0 ${W} ${H}`);
 const land=`<polygon points="${poly(GB)}"/><polygon points="${poly(NI)}"/>`,k=Math.max(1,(z-4)*.8);
 if(z>=9&&tilesOK)ov.innerHTML=cells+pins+cur;
 else{const fx='';
 ov.innerHTML=`<defs><clipPath id="uk">${land}</clipPath></defs><rect width="${W}" height="${H}" fill="#1a6aa0"/>
 <g fill="none" stroke="#fff" stroke-linejoin="round"><g stroke-width="${44*k}" opacity=".07">${land}</g><g stroke-width="${28*k}" opacity=".1">${land}</g><g stroke-width="${14*k}" opacity=".16">${land}</g><g stroke-width="${3*k}" stroke-dasharray="${8*k} ${10*k}" opacity=".55" transform="translate(0 0)">${land}</g></g>
 ${fx}<g fill="#1f6b3f" stroke="#0d3b26" stroke-width="${1.5*Math.min(k,3)}" stroke-linejoin="round">${land}</g>
 <g clip-path="url(#uk)">${cells}</g>${pins}${cur}`}
 drawNews();
 $('reps').innerHTML=reports.length?reports.slice().sort((a,b)=>b.t-a.t).slice(0,6).map(r=>`<div class="rep">${r.img?`<img src="${esc(r.img)}" alt="">`:''}<div><b>${(r.items||[]).map(i=>esc(i.count)+' '+esc(i.type)).join(', ')||'Trash'}</b><br><span class="mute">${r.lat.toFixed(4)}, ${r.lon.toFixed(4)} · penalty ${penalty(r.items)}</span></div></div>`).join(''):'Nothing reported yet.';
}
function zoomBy(d,ox=W/2,oy=H/2){const nz=Math.max(5,Math.min(19,V.z+d));if(nz===V.z)return;const f=2**(nz-V.z),dx=ox-W/2,dy=oy-H/2;V.cx=(V.cx+dx)*f-dx;V.cy=(V.cy+dy)*f-dy;V.z=nz;render()}
let last=0,drag=null;
wrap.addEventListener('wheel',e=>{e.preventDefault();if(Date.now()-last<140)return;last=Date.now();const r=wrap.getBoundingClientRect();zoomBy(e.deltaY<0?1:-1,e.clientX-r.left,e.clientY-r.top)},{passive:false});
wrap.addEventListener('dblclick',e=>{const r=wrap.getBoundingClientRect();zoomBy(1,e.clientX-r.left,e.clientY-r.top)});
wrap.addEventListener('pointerdown',e=>{if(e.target.closest('.ctl,#sb'))return;drag={x:e.clientX,y:e.clientY,m:false};wrap.setPointerCapture(e.pointerId)});
wrap.addEventListener('pointermove',e=>{
 if(drag){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(drag.m||Math.abs(dx)+Math.abs(dy)>4){drag.m=true;V.cx-=dx;V.cy-=dy;drag.x=e.clientX;drag.y=e.clientY;render()}return}
 const k=e.target.dataset&&e.target.dataset.k;if(!k)return;const c=cellsData()[k];
 $('cellinfo').innerHTML=`Clean score <b style="color:${col(score(c.p))}">${score(c.p)}/100</b><br><span class="mute">${c.n} report(s) in this area</span>`});
wrap.addEventListener('pointerup',e=>{if(drag&&!drag.m){const r=wrap.getBoundingClientRect();setPin(ilon(V.cx+e.clientX-r.left-W/2,V.z),ila(V.cy+e.clientY-r.top-H/2,V.z))}drag=null});
$('zi').onclick=()=>zoomBy(1);$('zo').onclick=()=>zoomBy(-1);
function setPin(lo,la,fly){pinned={lat:la,lon:lo};$('pin').textContent=`Location: ${la.toFixed(5)}, ${lo.toFixed(5)}`;if(fly)setView(lo,la,17);else render()}
$('q').onkeydown=async e=>{if(e.key!=='Enter')return;try{const r=await(await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=gb&q='+encodeURIComponent(e.target.value))).json();
 if(r[0])setView(+r[0].lon,+r[0].lat,16);else $('msg').textContent='Address not found.'}catch(x){$('msg').textContent='Address search needs the self-hosted version (blocked inside claude.ai).'}};
$('loc').onclick=()=>navigator.geolocation&&navigator.geolocation.getCurrentPosition(p=>setView(p.coords.longitude,p.coords.latitude,16),()=>$('msg').textContent='Location not available here.');
// ---- EXIF GPS ----
async function exifGPS(f){try{const v=new DataView(await f.slice(0,262144).arrayBuffer());if(v.getUint16(0)!==0xFFD8)return null;let o=2;
 while(o<v.byteLength-4&&v.getUint16(o)!==0xFFE1)o+=2+v.getUint16(o+2);if(v.getUint32(o+4)!==0x45786966)return null;
 const t=o+10,le=v.getUint16(t)===0x4949,g16=a=>v.getUint16(a,le),g32=a=>v.getUint32(a,le);
 const ifd=(a,tag)=>{const c=g16(a);for(let i=0;i<c;i++){const e=a+2+i*12;if(g16(e)===tag)return e}return null};
 const ge=ifd(t+g32(t+4),0x8825);if(!ge)return null;const gp=t+g32(ge+8),c=g16(gp),G={};
 for(let i=0;i<c;i++){const e=gp+2+i*12,tg=g16(e);G[tg]=tg===1||tg===3?String.fromCharCode(v.getUint8(e+8)):[0,1,2].map(k=>{const a=t+g32(e+8)+k*8;return g32(a)/g32(a+4)})}
 const d=a=>a[0]+a[1]/60+a[2]/3600;if(!G[2]||!G[4])return null;return{lat:d(G[2])*(G[1]==='S'?-1:1),lon:d(G[4])*(G[3]==='W'?-1:1)}}catch(e){return null}}
function shrink(f){return new Promise(res=>{const im=new Image();im.onload=()=>{const s=Math.min(1,800/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*s;c.height=im.height*s;c.getContext('2d').drawImage(im,0,0,c.width,c.height);c.toBlob(b=>res(b),'image/jpeg',.8)};im.onerror=()=>res(f);im.src=URL.createObjectURL(f)})}
// ---- upload flow: photo -> GPS -> AI count -> editable review ----
$('photo').onchange=async()=>{const f=$('photo').files[0],msg=$('msg');if(!f)return;
 msg.textContent='Reading photo location…';const g=await exifGPS(f);
 if(g)setPin(g.lon,g.lat,true);else{pinned=null;$('pin').textContent='No location in this photo – click the map to place the pin.'}
 photoBlob=await shrink(f);draft=[{type:'other',count:1}];
 if(useSample){msg.textContent='AI is counting the pieces…';
  try{const a=await useSample.json(`Count the individual pieces of litter in this photo and identify each one's material. Reply ONLY JSON: {"items":[{"type":"plastic|glass|metal|paper|food|cigarettes|hazardous|flytipping|other","count":number}]}. One entry per material. Estimate if unsure.`,{images:photoBlob,cache:false});
   if(a&&Array.isArray(a.items)&&a.items.length)draft=a.items.filter(i=>i&&i.type).map(i=>({type:i.type,count:+i.count||1}));msg.textContent='AI finished – please check the list below.'}
  catch(e){msg.textContent='AI unavailable – enter the items manually.'}}else msg.textContent='Enter what you found below.';
 drawRows();$('rev').classList.remove('hide')};
function drawRows(){$('rows').innerHTML=draft.map((d,i)=>`<div class="ir"><select data-i="${i}" data-f="type">${Object.keys(WEIGHTS).map(t=>`<option ${t===d.type?'selected':''}>${t}</option>`).join('')}</select><input type="number" min="1" value="${d.count}" data-i="${i}" data-f="count"><button class="s" data-del="${i}">✕</button></div>`).join('')}
$('rows').onchange=e=>{const d=e.target.dataset;if(d.f)draft[d.i][d.f]=d.f==='count'?Math.max(1,+e.target.value||1):e.target.value};
$('rows').onclick=e=>{const i=e.target.dataset.del;if(i!==undefined){draft.splice(i,1);drawRows()}};
$('addrow').onclick=()=>{draft.push({type:'plastic',count:1});drawRows()};
$('go').onclick=async()=>{const msg=$('msg');if(!pinned)return msg.textContent='Click the map to set a location first.';if(!draft.length)return msg.textContent='Add at least one item.';
 $('go').disabled=true;try{let img='';if(assets&&photoBlob){try{img=(await assets.upload(photoBlob)).url}catch(e){}}
  const rep={lat:pinned.lat,lon:pinned.lon,items:draft,img,by:uid||localId,t:Date.now()};
  if(db)await db.doc('reports/'+rep.t+'_'+localId).set(rep);else{real.push(rep);render()}
  msg.textContent='Submitted – the map has updated.';$('photo').value='';$('rev').classList.add('hide')}
 catch(e){msg.textContent='Could not submit: '+(e.message||e.code||'error')+(db?' (you may need contributor access)':'')}$('go').disabled=false};
const localId=Math.random().toString(36).slice(2);
// ---- joint cleans ----
function drawEv(){const now=Date.now(),l=allEv().filter(e=>e.when>now-864e5).sort((a,b)=>a.when-b.when);
 $('evs').innerHTML=l.length?l.map(e=>{const d=new Date(e.when),going=(e.rsvp||[]).includes(uid||localId);
  return `<div class="ev"><div class="date"><b>${d.getDate()}</b>${d.toLocaleString('en-GB',{month:'short'})}</div><div style="flex:1"><b>${esc(e.title)}</b><br><span class="mute">${d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})} · ${esc(e.loc)} · ${(e.rsvp||[]).length} going</span></div><button class="p" style="margin:0" data-id="${esc(e.id)}">${going?'Cancel RSVP':'RSVP'}</button></div>`}).join(''):'No cleans planned yet – create one!'}
$('evs').onclick=async e=>{const id=e.target.dataset.id;if(!id)return;const ev=allEv().find(x=>x.id===id),me=uid||localId;
 const r=(ev.rsvp||[]).includes(me)?ev.rsvp.filter(x=>x!==me):[...(ev.rsvp||[]),me];
 if(ev.demo){ev.rsvp=r;drawEv()}else if(db){try{await db.doc('events/'+id).update({rsvp:r})}catch(x){$('emsg').textContent='Could not RSVP.'}}else{ev.rsvp=r;drawEv()}};
$('eadd').onclick=async()=>{const t=$('et').value.trim(),d=$('ed').value,l=$('el').value.trim();
 if(!t||!d||!l)return $('emsg').textContent='Fill in title, date and location.';
 const ev={id:Date.now()+'_'+localId,title:t,loc:l,when:new Date(d).getTime(),rsvp:[uid||localId],by:uid||localId};
 try{if(db)await db.doc('events/'+ev.id).set(ev);else{events.push(ev);drawEv()}$('emsg').textContent='Event created!';$('et').value=$('el').value=''}catch(e){$('emsg').textContent='Could not create event.'}};
[1,2,3,4,5].forEach(n=>$('t'+n).onclick=()=>{[1,2,3,4,5].forEach(m=>{$('v'+m).classList.toggle('hide',m!==n);$('t'+m).classList.toggle('on',m===n)});render()});
// ---- demo data (delete this block and the checkbox to remove) ----
let showDemo=true,showPins=false;const rnd=(x=>()=>(x=x*16807%2147483647)/2147483647)(7),TY=Object.keys(WEIGHTS),DEMO=[];
[[-.12,51.5,40,.12,6],[-2.24,53.48,30,.1,5],[-1.9,52.48,30,.1,5],[-4.25,55.86,26,.1,4],[-3.19,55.95,14,.08,1],[-3.18,51.48,16,.08,2],[-5.93,54.6,20,.08,3],[-1.55,53.8,20,.08,3],[-2.6,51.45,14,.07,1],[-1.61,54.97,16,.07,3],[-2.98,53.41,24,.08,4]].forEach(([lo,la,n,sp,k])=>{for(let i=0;i<n;i++)DEMO.push({lat:la+(rnd()-.5)*sp*2,lon:lo+(rnd()-.5)*sp*3,items:[{type:TY[Math.floor(rnd()*TY.length)],count:1+Math.floor(rnd()*k)},{type:TY[Math.floor(rnd()*4)],count:1+Math.floor(rnd()*k)}],by:'demo',t:Date.now()-rnd()*6e8})});
[[-3.9,53],[-3.1,54.5],[-3.7,57.1],[-1.8,53.3],[-3.9,50.6],[-1.8,51.8],[-2.2,54.25],[1,52.9],[-5,57.6],[-2.5,55.3]].forEach(([lo,la])=>DEMO.push({lat:la,lon:lo,items:[{type:'paper',count:1}],by:'demo',t:Date.now()-rnd()*6e8}));
Object.defineProperty(window,'reports',{get:()=>showDemo?DEMO.concat(real):real});
const DEMOEV=[['Riverside litter pick','London · Putney Bridge',3,10,14],['Beach clean','Edinburgh · Portobello Beach',6,11,9],['Canal towpath sweep','Manchester · Castlefield',9,10,18],['Park & playground blitz','Glasgow · Kelvingrove Park',12,13,7]].map(([title,loc,d,h,g],i)=>{const t=new Date(Date.now()+d*864e5);t.setHours(h,0,0,0);return{id:'demo'+i,demo:1,title,loc,when:t.getTime(),rsvp:Array.from({length:g},(_,j)=>'d'+j)}});
const allEv=()=>showDemo?DEMOEV.concat(events):events;
$('pinsw').onchange=e=>{showPins=e.target.checked;render()};
$('demo').onchange=e=>{showDemo=e.target.checked;render();drawEv()};
// ---- donate: edit prices here ----
const GIVE=[{id:'bags',name:'Roll of 20 bin bags',price:4,icon:'🗑️'},{id:'picker',name:'Litter picker',price:10,icon:'🧤'}];
$('gi').innerHTML=GIVE.map(g=>`<option value="${g.id}">${g.name} (£${g.price} each)</option>`).join('');
$('gimp').innerHTML=GIVE.map(g=>`<p>${g.icon} <b>£${g.price}</b> = 1 ${g.name.toLowerCase()}</p>`).join('');
// ---- kit bank: stock everyone can see. Edit STOCK defaults here (in = donated, out = lent out) ----
let STOCK={bags:{in:120,out:45},picker:{in:30,out:12}},isAdmin=false;
function drawBank(){$('bank').innerHTML=GIVE.map(g=>{const s=STOCK[g.id]||{in:0,out:0},av=Math.max(0,s.in-s.out),pc=s.in?Math.round(av/s.in*100):0;
 return `<div class="pr"><div class="i">${g.icon}</div><b class="n">${av}</b>${g.name} available<div class="mute">${s.in} donated · ${s.out} lent out</div><div style="height:6px;border-radius:3px;background:var(--line);margin-top:6px"><div style="height:6px;border-radius:3px;width:${pc}%;background:linear-gradient(90deg,var(--acc),var(--blue))"></div></div></div>`}).join('');$('badm').classList.toggle('hide',!isAdmin)}
$('badm').innerHTML=`<label>Update stock (admins only)</label><div class="ir" style="grid-template-columns:1fr 1fr 80px"><select id="bk">${GIVE.map(g=>`<option value="${g.id}">${g.name}</option>`).join('')}</select><select id="bt"><option value="in">Received</option><option value="out">Lent out</option></select><input id="bn" type="number" min="1" value="1"></div><button class="p" id="bset">Apply</button>`;
$('bset').onclick=async()=>{const k=$('bk').value,t=$('bt').value,n=Math.max(1,+$('bn').value||1);STOCK[k]={in:0,out:0,...STOCK[k]};STOCK[k][t]+=n;
 if(db){try{await db.doc('stock/main').set(STOCK);$('bnote').textContent='Stock updated.'}catch(e){$('bnote').textContent='Could not save stock.'}}drawBank()};
drawBank();
function gtot(){const g=GIVE.find(x=>x.id===$('gi').value),q=Math.max(1,+$('gq').value||1);$('gtot').textContent=`${q} × ${g.name} = £${(q*g.price).toFixed(2)}`}
$('gi').onchange=$('gq').oninput=gtot;gtot();
$('give').onclick=()=>$('gmsg').textContent="Payments aren't connected in this preview – a provider like Stripe would go here.";
// ---- good news: replace these sample stories with real ones ----
const NEWS=[{t:'Sample story: a riverside cleared in a morning',d:'[date]',x:'[Sample – replace with a real story.] Neighbours met at the bridge and filled bags in a single morning.'},{t:'Sample story: a school takes on its local park',d:'[date]',x:'[Sample – replace with a real story.] A class mapped litter on JSN, then organised a clean.'},{t:'Sample story: a beach ready for summer',d:'[date]',x:'[Sample – replace with a real story.] Volunteers, a council bag collection and lots of tea.'}];
$('stories').innerHTML=NEWS.map(n=>`<div class="story"><b>${esc(n.t)}</b> <span class="mute">${esc(n.d)}</span><br>${esc(n.x)}</div>`).join('');
function drawNews(){if(!$('stats'))return;const cd=cellsData(),good=Object.values(cd).filter(c=>score(c.p)>=80).length,ev=allEv(),vol=ev.reduce((a,e)=>a+(e.rsvp||[]).length,0);
 $('stats').innerHTML=[[reports.length,'reports logged'],[good,'clean areas (80+)'],[ev.length,'cleans planned'],[vol,'volunteers signed up']].map(([n,l])=>`<div class="pr"><b class="n">${n}</b>${l}</div>`).join('')+(showDemo?'<p class="mute" style="grid-column:1/-1">Includes demo data – untick "Show demo data" on the map.</p>':'')}
window.addEventListener('resize',render);
setView(-2.5,54.3,5);drawEv();
(async()=>{try{const c=window.claude;if(!c)return;
 const u=await c.use('user');if(u){try{uid=await u.id();$('who').textContent='Signed in'}catch(e){}try{isAdmin=!!u.canEdit();drawBank()}catch(e){}}
 assets=await c.use('assets');
 const s=await c.use('sample');if(s){try{if((await s.limits()).images)useSample=s}catch(e){}}
 db=await c.use('db');
 if(db){db.doc('stock/main').onSnapshot(d=>{if(d.exists){STOCK=d.data();drawBank()}});db.collection('reports').onSnapshot(q=>{real=q.docs.map(d=>d.data());render()});
  db.collection('events').onSnapshot(q=>{events=q.docs.map(d=>d.data());drawEv()})}
}catch(e){}})();